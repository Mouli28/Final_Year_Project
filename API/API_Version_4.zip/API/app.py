from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options, Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
import pandas as pd
from bs4 import BeautifulSoup
import re


def setup_driver():
    options = Options()
    options.add_argument('--disable-gpu')
    options.add_argument('--no-sandbox')
    options.add_argument('--incognito')
    options.add_argument('--lang=en-US')
    service = Service('/snap/bin/chromium.chromedriver')
    return webdriver.Chrome(service=service, options=options)


def get_google_search_urls(query, num_results):
    """
    Retrieves URLs from Google search results for the given query.
    Returns a list of URLs.
    """
    driver = setup_driver()
    search_urls = []
    sites = ['autozone.com','kalpartz.com','shopadvanceautoparts.com','vanhorntruckparts.com','ebay.com','nickstruckparts.com','thewrenchmonkey.com','finditparts.com','www.amazon.com','accessorymods.com','centralalbertapaintsupply','fleetpride.com']
    required_results = (len(sites) * 2) + num_results
    try:
        # Step 1: Search each trusted site individually, taking only 2 URLs per site
        for site in sites:
            site_query = f"{query} {site}"
            driver.get("https://www.google.com")
            search_box = driver.find_element(By.NAME, "q")
            search_box.send_keys(site_query)
            search_box.send_keys(Keys.RETURN)

            # Wait a shorter time for results (5 seconds) to avoid hanging on zero-result pages
            try:
                WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, "div.yuRUbf a")))
                results = driver.find_elements(By.CSS_SELECTOR, "div.yuRUbf a")[:2]
                site_urls = [result.get_attribute("href") for result in results]
                search_urls.extend(site_urls)
            except Exception as e:
                print(f"No results for {site}, moving to the next site.")

            # Stop if we reach the required results
            if len(search_urls) >= required_results:
                break


        # Step 2: Perform a general search if not enough results from trusted sites
        if len(search_urls) < required_results:
            general_query = f"{query}"
            driver.get("https://www.google.com")
            search_box = driver.find_element(By.NAME, "q")
            search_box.send_keys(general_query)
            search_box.send_keys(Keys.RETURN)
            WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, "div.yuRUbf a")))

            # Extract URLs from the first page of the general search
            results = driver.find_elements(By.CSS_SELECTOR, "div.yuRUbf a")
            general_urls = [result.get_attribute("href") for result in results]
            search_urls.extend(general_urls)

            # Fetch additional pages if needed
            while len(search_urls) < required_results:
                try:
                    next_button = driver.find_element(By.ID, "pnnext")
                    next_button.click()
                    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, "div.yuRUbf a")))
                    results = driver.find_elements(By.CSS_SELECTOR, "div.yuRUbf a")
                    search_urls.extend([result.get_attribute("href") for result in results])
                except Exception as e:
                    print(f"Error navigating to the next page: Endind of the list")
                    break

    finally:
        driver.quit()

    return search_urls

def extract_data(patterns,text):
    extracted = {}
    for key, pattern in patterns.items():
        match = re.search(pattern, str(text))
        if match:
            extracted[key] = match.group(1).strip()
    return extracted


def site_specific_extraction(url, part_column, cross_ref_column):
    patterns = {
    'sku' : r'\s*#\s*(\S+)SKU',
    'SKU': r'SKU\s*#\s*(\S+)',
    'Part' : r'Part\s*#\s*(\S+)',
    'Same As': r'Same As\s*([A-Za-z0-9,\s.-]+)',
    'Part Interchanges': r'Part Interchanges\s*([A-Za-z0-9,\s.-]+)',
    'OE Numbers': r'OE Numbers\s*([A-Za-z0-9,\s.-]+)',
    'OE Cross Reference': r'OE Cross Reference\s*([A-Za-z0-9,\s.-]+)'
    }
    if 'fleetpride' in url:
        # Example: Extract entire part number and cross-reference from Amazon
        return part_column,cross_ref_column
    elif 'baltimoreauto' in url:
        # Example: Extract data directly without pattern-matching
        return part_column,cross_ref_column
    else:
        # Default: Use pattern-based extraction
        part_data = extract_data(patterns, part_column)
        cross_ref_data = extract_data(patterns, cross_ref_column)
        
        return (
            ', '.join([f'{k}: {v}' for k, v in part_data.items()]) if part_data else None,
            ', '.join([f'{k}: {v}' for k, v in cross_ref_data.items()]) if cross_ref_data else None
        )


def mrk(df):
    filtered_df = df.dropna(subset=['Part_No from site', 'Cross Reference'], how='all')
    return filtered_df

def price_comparison(query, num_results, part_num, description, mfr):
    """
    Performs price comparison for the given query by extracting product details from multiple websites.
    Returns a pandas DataFrame containing the product details.
    """
    driver = setup_driver()
    urls = get_google_search_urls(query, num_results)
    # #urls_list = urls_list.tolist()

    # urls = list(set(urls_list))
    #print(urls)
    #urls = ['https://www.continentalbattery.com/product-reference/advance-diehard-silver-561','https://www.amazon.com/Dorman-485-701-Grease-Fitting/dp/B0036C9DR0','https://excofilter.com/description/AX230207/93800-CARQUEST']
    all_product_details = []
    #urls = [' https://nickstruckparts.com/products/coolantelbow-561-17275-polyester-reinforced-45-deg?srsltid=AfmBOoqwPg0RDxkqbjqBBDDZBwMLwX5sUIjiF4UZarahHiC0qeQUOsXk']
    for url in urls:
        try:
            #print(class_names)
            # Gather product details
            details = {
            'MFR Line' : mfr,
            'Part Num to search': part_num,
            'Description' : description,
            'url': url,
            'Part_No from site': extract_product_details(url,['product_info__description_list','part_number', 'partNumSection', 'part-number', 'product_part-info', 'item-part-number','sku','sku number','item part number','part number','item no','product-basic-details__text--part'],driver),
            'Cross Reference': extract_product_details(url,['product-specifications','interchange category-description','cross-reference','other-cross-refrence','product-description rte','productDescription','crossRefWrapper','interchangeItemValue','productDetails_techSpec_section_1','product-details-d','css-cm8roc','product_description__row','product-part-interchange','product-specifications-container','cross-reference-list','product-single__description','x-item-description-child','interchange','Crossreference','replaces', 'product superseded','superseded','interchages'],driver)
            }
            #print(details)
            all_product_details.append(details)
            print(f"Website done: {url}")

        except Exception as e:
            print(f"Error processing URL {url}: {e}")
    driver.quit()
    df = pd.DataFrame(all_product_details)
    #df = mrk(df_unfiltered)
    
    df[['Extracted_Part No From Site', 'Extracted_Cross Reference']] = df.apply(lambda row: site_specific_extraction(row['url'], row['Part_No from site'], row['Cross Reference']), 
    axis=1, result_type='expand')
    return df


def normalize_string(s):
        """Helper function to normalize strings by removing spaces, dashes, and underscores."""
        return re.sub(r'[\s+\-\_+]', '', s).lower()


def extract_data_from_elements(elements, substrings_set):
        """Helper function to extract data based on class names or IDs."""
        extracted_data = []
        
        for element in elements:
            element_classes = element.get('class', [])
            element_id = element.get('id', '')

            # Check if any substring matches the normalized class or ID
            if any(substr in normalize_string(cls) for cls in element_classes + [element_id] for substr in substrings_set):
                #print(element)
                #extracted_text = re.sub(r'\s+', ' ', element.get_text())
                extracted_text = ' '.join(element.stripped_strings) 
                #print(extracted_text)
                #print("-------------------------------------")
                if extracted_text:
                    # Append each piece of text as a separate element
                    extracted_data.append(extracted_text)
                

        return ' '.join(extracted_data)



def extract_product_details(url, substrings, driver):
        # Navigate to the URL
    driver.get(url)
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.TAG_NAME, 'body')))

    # Normalize substrings in advance to avoid repeated computation
    substrings_set = {normalize_string(substr) for substr in substrings}

    # Extract data from the main page
    main_soup = BeautifulSoup(driver.page_source, 'html.parser')
    extracted_data = extract_data_from_elements(main_soup.find_all(), substrings_set)

    for iframe in driver.find_elements(By.TAG_NAME, 'iframe'):
        try:
            driver.switch_to.frame(iframe)
            iframe_soup = BeautifulSoup(driver.page_source, 'html.parser')
            iframe_data = extract_data_from_elements(iframe_soup.find_all(), substrings_set)
            
            # If iframe_data is not empty, extend the main extracted data
            if iframe_data:
                #extracted_data.join(' ' + iframe_data)
                extracted_data += ' ' + iframe_data
        except Exception as e:
            print(f"Error processing iframe: {e}")
        finally:
            driver.switch_to.default_content()

    return extracted_data


@app.route('/')
def index():
    return render_template('index.html')



@app.route('/extraction', methods=['POST'])
def compare_prices():
    data = request.json
    input_str = data.get('input_str', '')
    queries = input_str.split('|')
    part_num = queries[0].strip()
    description = queries[1].strip()
    brand = queries[2].strip()
    query = f"{part_num} {description} {brand}"

    df = price_comparison(query, num_results=5, part_num=part_num, description=description, mfr=brand)
    file_name = f"{query.replace(' ', '_')}_part_details.json"
    result = df.to_json(file_name, orient='records', indent=4)
    return result

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
