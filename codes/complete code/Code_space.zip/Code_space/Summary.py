import json
import re
from nltk.tokenize import sent_tokenize
from transformers import pipeline, AutoTokenizer
from tqdm import tqdm
import nltk


nltk.download('punkt_tab')

# === Step 1: Load summarizer and tokenizer ===
summarizer = pipeline("summarization", model="google/flan-t5-large", device=0)
tokenizer = AutoTokenizer.from_pretrained("google/flan-t5-large")

# === Step 2: Sentence-based preprocessor ===
def preprocess_text_from_sample(sample):
    text = f"{sample['Generated Output']}"
    text = re.sub(r"\s+", " ", text).strip()
    text = re.sub(r"[^\w\s.,!?]", "", text)  # Remove special characters
    sentences = sent_tokenize(text)
    unique_sentences = list(set(sentences))
    return " ".join(unique_sentences)

# === Step 3: Sentence-based chunking ===
def chunk_text_via_sentences(text, max_chunk_tokens=200):
    sentences = sent_tokenize(text)
    chunks, current_chunk = [], []

    for sentence in sentences:
        test_chunk = " ".join(current_chunk + [sentence])
        if len(tokenizer.encode(test_chunk, truncation=False)) <= max_chunk_tokens:
            current_chunk.append(sentence)
        else:
            if current_chunk:
                chunks.append(" ".join(current_chunk))
            current_chunk = [sentence]

    if current_chunk:
        chunks.append(" ".join(current_chunk))

    return chunks

# === Step 4: Merge small chunks ===
def merge_small_chunks(chunks, min_words=30):
    merged_chunks = []
    temp_chunk = ""

    for chunk in chunks:
        if len(chunk.split()) < min_words:
            temp_chunk += " " + chunk
        else:
            if temp_chunk.strip():
                merged_chunks.append(temp_chunk.strip())
                temp_chunk = ""
            merged_chunks.append(chunk)

    if temp_chunk.strip():
        merged_chunks.append(temp_chunk.strip())

    return merged_chunks

# === Step 5: Generate summaries ===
def summarize_chunks(text_chunks, max_length=200, min_length=10):
    summaries = []
    for chunk in text_chunks:
        try:
            summary = summarizer(chunk, max_length=max_length, min_length=min_length, truncation=True)[0]['summary_text']
            summaries.append(summary)
        except Exception as e:
            print(f"❌ Error summarizing chunk: {e}")
            summaries.append("")
    return " ".join(summaries)

# === Step 6: Summarize all samples ===
def summarize_sample_outputs(json_file_path, output_file_path):
    with open(json_file_path, "r") as f:
        data = json.load(f)

    all_summaries = []

    for i, sample in tqdm(enumerate(data), total=len(data), desc="Summarizing samples"):
        cleaned_text = preprocess_text_from_sample(sample)
        chunks = chunk_text_via_sentences(cleaned_text, max_chunk_tokens=200)
        final_chunks = merge_small_chunks(chunks)
        summary = summarize_chunks(final_chunks)
        all_summaries.append({
            "Sample Index": i,
            "Summary": summary,
            "Generated Output": sample["Generated Output"]
        })

    with open(output_file_path, "w") as f:
        json.dump(all_summaries, f, indent=2)

    print(f"\n✅ All summaries saved to: {output_file_path}")

# === Run the Summarizer ===
input_json = "./Project/evaluation_outputs/sample_outputs.json"
output_json = "./Project/evaluation_outputs/summarized_outputs.json"  # You can also save it to Google Drive path if needed

summarize_sample_outputs(input_json, output_json)
