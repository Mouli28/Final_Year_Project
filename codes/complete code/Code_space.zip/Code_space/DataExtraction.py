import torch
import json
import re
from tqdm import tqdm
from datasets import load_dataset
from transformers import AutoTokenizer

# === Step 1: Load Tokenizer and Model ===
model_path = "./Project/model/Final model/llama3.pt"  # Your .pt model
dataset_path = "./Project/dataset/final_datasetnl.jsonl"

# Import your custom model definition
# Make sure Llama3Model and LLAMA32_CONFIG_1B are already defined in the notebook
tokenizer = AutoTokenizer.from_pretrained("google/flan-t5-base")
tokenizer.pad_token = tokenizer.eos_token

# Load model structure
model = Llama3Model(LLAMA32_CONFIG_1B)
model.load_state_dict(torch.load(model_path, map_location="cuda" if torch.cuda.is_available() else "cpu"))
model.to("cuda" if torch.cuda.is_available() else "cpu")
model.eval()

# === Step 2: Clean Input Text ===
def clean_text(text, max_len=5000):
    patterns = [
        r"(Sign in|Login|Register|Track Order|Feedback|My Cart|Help & Contact|Search|Sort By|Related Products|Back to top).*",
        r"(TOP SELLER|Menu|Customer Reviews|Ratings & Reviews|Recently Viewed|All rights reserved).*"
    ]
    for pattern in patterns:
        text = re.sub(pattern, "", text, flags=re.IGNORECASE | re.DOTALL)
    text = re.sub(r"\s+", " ", text).strip()
    return text[:max_len]

# === Step 3: Load Dataset ===
dataset = load_dataset("json", data_files={"data": dataset_path})["data"]
dataset = dataset.filter(lambda x: len(x["input"]) > 10)

samples = []
# === Step 4: Evaluation Loop ===
device = next(model.parameters()).device  # ✅ Get model's device

for sample in tqdm(dataset.select(range(20))):  # Quick test on 20 samples
    cleaned_text = clean_text(sample["input"])

    # 🔁 Enhanced prompt to prioritize alternate part number inference
    prompt = (
       "You are an expert structured data extractor. "
        "Extract the following fields in JSON like format:\n"
        "- product_name\n"
        "- alternates (with OEM_part_number and Alternate_part_number)\n\n"
        f"Product Description:\n{cleaned_text}"
    )

    # Tokenize and move to device
    inputs = tokenizer(prompt, return_tensors="pt", truncation=True)
    inputs = {k: v.to(device) for k, v in inputs.items()}

    with torch.no_grad():
      output = generate(
        model=model,
        idx=inputs["input_ids"],
        max_new_tokens=100,
        context_size=inputs["input_ids"].shape[1],
        temperature=0.7,
        top_k=50,
        eos_id=tokenizer.eos_token_id
    )


    decoded_output = tokenizer.decode(output[0], skip_special_tokens=True)

    samples.append({
        "Prompt": prompt,
        "Generated Output": decoded_output,
        "Ground Truth": sample.get("output", None)
    })

# === Step 5: Display a Few Examples ===
print("\n🔍 Sample Outputs:")
for i, s in enumerate(samples[:5], 1):
    print(f"\n--- Sample {i} ---")
    print("Prompt:\n", s["Prompt"])
    print("Ground Truth:\n", s["Ground Truth"])
    print("Generated Output:\n", s["Generated Output"])