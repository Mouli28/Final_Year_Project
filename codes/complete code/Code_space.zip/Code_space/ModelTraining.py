import torch
from transformers import AutoTokenizer,AutoModelForCausalLM,TrainingArguments,Trainer,DataCollatorForLanguageModeling,BitsAndBytesConfig
from datasets import load_dataset
from datasets import Dataset
from peft import get_peft_model, LoraConfig, TaskType
import json
import re

# === Step 1: Generalized Text Cleaner ===
def clean_text(text, max_len=700):
    patterns = [
        r"(Sign in|Login|Register|My Account|My Cart|Sell|Deals|Gift Cards|Help & Contact|Track Order|Back to top|Feedback)",
        r"(Add to Cart|Buy Now|Sort By|More Filters|Search|Search Products|Advanced Search|Shop Now|Brand Outlet)",
        r"(Customer Reviews|Ratings & Reviews|Estimated delivery|Return policy|Shipping & Returns|Secure Shopping|Contact Seller)",
        r"(Related Products|Recently Viewed|You may also like|eBay Home|Amazon Home|Shop by Category|Menu|Navigation)"
    ]
    for pattern in patterns:
        text = re.sub(pattern, '', text, flags=re.IGNORECASE)
    text = re.sub(r"\s+", " ", text).strip()
    return text[:max_len]

# === Step 2: Load and Filter Dataset ===
dataset = "/dataset1_cleaned_structured.jsonl"


with open(dataset, "r") as f:
    raw_data = [json.loads(line) for line in f if line.strip()]

# === Step 2: Convert to HuggingFace Dataset ===
dataset = Dataset.from_list(raw_data)

# === Step 3: Filter Invalid Rows ===
def is_valid(example):
    try:
        parsed = json.loads(example["completion"])
        return bool(parsed) and len(example["prompt"].split()) > 10
    except:
        return False

dataset = dataset.filter(is_valid)
dataset = dataset.train_test_split(test_size=0.1)

# === Step 4: Load Tokenizer ===
model_name = "unsloth/Meta-Llama-3.1-8B-Instruct"
tokenizer = AutoTokenizer.from_pretrained(model_name)
tokenizer.pad_token = tokenizer.eos_token

# === Step 5: Tokenize Dataset ===
def tokenize_function(examples):
    inputs = examples["prompt"]
    targets = []
    for c in examples["completion"]:
        try:
            parsed_json = json.loads(c.strip())
            compacted = json.dumps(parsed_json, separators=(",", ":"))
        except:
            compacted = "{}"
        targets.append(compacted)

    full_texts = [f"{i}\n{t}" for i, t in zip(inputs, targets)]

    return tokenizer(
        full_texts,
        padding=True,
        truncation=True,
        max_length=512,
        return_tensors="pt"
    )

tokenized_datasets = dataset.map(tokenize_function, batched=True)

# === Step 6: Load 4-bit Quantized Model ===
bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_compute_dtype=torch.float16,
    bnb_4bit_use_double_quant=True
)

model = AutoModelForCausalLM.from_pretrained(
    model_name,
    quantization_config=bnb_config,
    device_map="auto",
    torch_dtype=torch.float16
)

model.gradient_checkpointing_enable()
model.config.use_cache = False
if hasattr(model, "enable_input_require_grads"):
    model.enable_input_require_grads()
if hasattr(model, "enable_flash_attention_2"):
    model.enable_flash_attention_2()

print("Base model loaded in 4-bit.")

# === Step 7: Apply LoRA Adapter ===
lora_config = LoraConfig(
    task_type=TaskType.CAUSAL_LM,
    r=8,
    lora_alpha=32,
    lora_dropout=0.05
)
model = get_peft_model(model, lora_config)

# === Step 8: Training Arguments ===
training_args = TrainingArguments(
    output_dir="./Project/model",
    per_device_train_batch_size=4,
    gradient_accumulation_steps=2,
    num_train_epochs=100,
    save_total_limit=1,
    fp16=False,
    logging_strategy="steps",
    logging_steps=5,
    learning_rate=2e-5,
    lr_scheduler_type="linear",
    optim="adamw_bnb_8bit",
    report_to="none",
    eval_strategy="steps",
    eval_steps=5
)

# === Step 9: Data Collator ===
data_collator = DataCollatorForLanguageModeling(
    tokenizer=tokenizer,
    mlm=False
)

# === Step 10: Trainer Setup ===
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=tokenized_datasets["train"],
    eval_dataset=tokenized_datasets["test"],
    data_collator=data_collator
)

# === Step 11: Train the Model ===
trainer.train()

# === Step 12: Save the LoRA Adapter and Tokenizer ===
adapter_save_path = "./Project/model/finetuned_model_F"
model.save_pretrained(adapter_save_path)
tokenizer.save_pretrained(adapter_save_path)

print(f"LoRA adapter and tokenizer saved at: {adapter_save_path}")